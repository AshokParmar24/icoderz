import Layout from "../../components/Loyout";
import CreateProduct from "../../components/Product/CreateProduct";

const CreateProductPage = () => {
  return (
    <Layout>
      <CreateProduct />
    </Layout>
  );
};

export default CreateProductPage;
