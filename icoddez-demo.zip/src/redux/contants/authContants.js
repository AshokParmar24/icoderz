export const STORE_TOKEN = "STORE_TOKEN";
export const REMOVE_TOKEN = "REMOVE_TOKEN";